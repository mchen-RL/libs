-= Rexster Console: A remote REPL for Rexster =-

Script evaluation within Rexster Console occurs remotely on a Rexster server.
Rexster Console communicates with any Gremlin-flavored JSR223 compliant ScriptEngine hosted within the Rexster server.
Rexster Console provides access to configured graphs within Rexster server.

